module Type



open Lang
open Parser
open System.Collections.Generic



type TypeError =
  | NotAFunction                    of Core
  | MissingTypeAnnotation           of Core
  | ParamNoType                     of string
  | NoReturnType                    of string
  | UndefinedVar                    of string
  | UndefinedType                   of string
  | TypeAlreadyDefined              of string
  | IfGuardNotBool                  of Type * Core
  | RecordLiteralInvalidField       of string
  | RecordLiteralMissingField       of string
  | RecordLiteralDuplicateField     of string
  | RecordLiteralUnexpectedType     of string * Type * Type
  | TupleProjectionInvalidIndex     of int
  | TupleProjectionInvalidTuple     of Type
  | RecordProjectionInvalidField    of string
  | RecordProjectionInvalidRecord   of Type
  | RecordDefinitionDuplicateField  of string * string
  | UnexpectedType                  of Type * Type * Core
  | IfArmsNotSame                   of Type * Type * Core
  | BopMismatch                     of Op * (Type * Type) * (Type * Type) list



exception TypeException of TypeError



let throw (err : TypeError) = raise (TypeException err)



type TypecheckResult =
  | Type      of Type
  | TypeError of TypeError



let baseTypeNames =
  [ "Int"
  ; "Bool"
  ; "String"
  ] |> Set.ofSeq



let tryFindDuplicate (xs : _ seq) =
    let s = System.Collections.Generic.HashSet(HashIdentity.Structural)
    let e = xs.GetEnumerator()
    let mutable found  = false
    let mutable result = None

    while e.MoveNext() && not found do
      let x = e.Current
      if s.Contains x
        then
          result <- Some x
          found  <- true
        else
          ignore (s.Add x)

    result



let tryFindMissing (xs : _ seq) (ys : _ seq) =
  let s = Seq.fold (fun acc k -> Set.add k acc) Set.empty ys
  let e = xs.GetEnumerator()
  let mutable found  = false
  let mutable result = None

  while e.MoveNext() && not found do
    let x = e.Current
    if Set.contains x s
      then ()
      else
        result <- Some x
        found  <- true

  result



let mapUnionWith onCollision m =
  let f acc (x, y) =
    match Map.tryFind x acc with
    | None   -> Map.add x y acc
    | Some z -> Map.add x (onCollision z y) acc

  Map.toSeq >> Seq.fold f m



let throwIfTypeUndefined env =
  let rec go =
    function
    | TSimple s ->
        if Set.contains    s baseTypeNames ||
           Map.containsKey s env
          then ()
          else throw (UndefinedType s)

    | TFun a ->
        Array.iter go a

    | TTuple a ->
        Array.iter go a

    | TList t -> go t

    | t -> ()

  go



let rec containsUnknown =
  function
  | TUnknown -> true
  | TList  t -> containsUnknown t
  | TFun   a -> Array.exists containsUnknown a
  | TTuple a -> Array.exists containsUnknown a
  | _        -> false



let rec typeOfBop (env : Map<string, Type>) =
  let ii = TInt      , TInt
  let bb = TBool     , TBool
  let ss = TString   , TString
  let ll = TList TAny, TList TAny

  let rec go =
    function
    | TInt, Add, TInt -> TInt
    | TInt, Sub, TInt -> TInt
    | TInt, Mul, TInt -> TInt
    | TInt, Div, TInt -> TInt
    | TInt, Eq , TInt -> TBool
    | TInt, Ne , TInt -> TBool
    | TInt, Lt , TInt -> TBool
    | TInt, Gt , TInt -> TBool
    | TInt, Le , TInt -> TBool
    | TInt, Ge , TInt -> TBool

    | TBool, Or , TBool -> TBool
    | TBool, Add, TBool -> TBool
    | TBool, Eq , TBool -> TBool
    | TBool, Ne , TBool -> TBool

    | t1, Cons  , TList t2 when t1 = t2 -> TList t1
    | t1, Cons  , TList TAny            -> TList t1
    | t1, Concat, TList t2 when t1 = t2 -> TList t1
    | t1, Concat, TList TAny            -> TList t1

    | TString, Concat, TString -> TString

    | t1, Add, t2 -> throw (BopMismatch(Add, (t1, t2), [ii]))
    | t1, Sub, t2 -> throw (BopMismatch(Sub, (t1, t2), [ii]))
    | t1, Mul, t2 -> throw (BopMismatch(Mul, (t1, t2), [ii]))
    | t1, Div, t2 -> throw (BopMismatch(Div, (t1, t2), [ii]))
    | t1, Lt , t2 -> throw (BopMismatch(Lt , (t1, t2), [ii]))
    | t1, Gt , t2 -> throw (BopMismatch(Gt , (t1, t2), [ii]))
    | t1, Le , t2 -> throw (BopMismatch(Le , (t1, t2), [ii]))
    | t1, Ge , t2 -> throw (BopMismatch(Ge , (t1, t2), [ii]))

    | t1, Or , t2 -> throw (BopMismatch(Or , (t1, t2), [bb]))
    | t1, And, t2 -> throw (BopMismatch(And, (t1, t2), [bb]))

    | t1, Eq , t2 -> throw (BopMismatch(Eq , (t1, t2), [ii; bb]))
    | t1, Ne , t2 -> throw (BopMismatch(Ne , (t1, t2), [ii; bb]))

    | t1, Concat, t2 -> throw (BopMismatch(Cons, (t1, t2), ([ll; ss])))
    | t1, Cons,   t2 -> throw (BopMismatch(Cons, (t1, t2), ([TAny, TList TAny])))

  function
  | Bop (e1, op, e2) -> go (typeOfExpr env e1, op, typeOfExpr env e2)
  | e                -> failwithf "Error @ typeOfBop: %A" e



and typeOfExpr (env : Map<string, Type>) : Core -> Type =
  function
  | Unit       -> TUnit
  | Int      _ -> TInt
  | Bool     _ -> TBool
  | String   _ -> TString
  | Bop _ as e -> typeOfBop env e

  | Var s ->
      match Map.tryFind s env with
      | Some t -> t
      | None   -> throw (UndefinedVar s)

  | App(e1, e2) ->
      match typeOfExpr env e1, typeOfExpr env e2 with
      | TFun a, t2 when a.[0] = t2 ->
          match a.[1..] with
          | [|t3|] -> t3
          |  ts    -> TFun ts

      | TFun a, t2 -> throw (UnexpectedType(a.[0], t2, App(e1, e2)))
      | _          -> throw (NotAFunction e1)

  | If(e1, e2, e3) ->
      match typeOfExpr env e1 with
      | TBool ->
           match (typeOfExpr env e2, typeOfExpr env e3) with
           | t1, t2 when t1 = t2 -> t1
           | t1, t2 -> throw (IfArmsNotSame(t1, t2, If(e1, e2, e3)))

      | t -> throw (IfGuardNotBool(t, If(e1, e2, e3)))

  | Core.Seq a when 2 <= Array.length a ->
      let es = a.[.. Array.length a - 2]
      let e  = Array.last a

      Array.iter (typeOfExpr env >> ignore) es;
      typeOfExpr env e

  | Abs(Untyped s, _) -> throw (ParamNoType s)

  | Abs(Typed(s, t1), e) ->
      throwIfTypeUndefined env t1;

      if containsUnknown t1
        then throw (MissingTypeAnnotation (Abs(Typed(s, t1), e)))
        else
          match typeOfExpr (Map.add s t1 env) e with
          | TFun a -> TFun (Array.append [|t1|] a)
          | t2     -> TFun [|t1; t2|]

  | TopLet(s, TUnknown, e) -> throw (NoReturnType s)

  | TopLet(s, t1, e) ->
      throwIfTypeUndefined env t1;

      if containsUnknown t1
        then throw (MissingTypeAnnotation (TopLet(s, t1, e)))
        else
          match t1, typeOfExpr env e with
          | t1, t2 when t1 = t2 -> t1
          | t1, t2 -> throw (UnexpectedType(t1, t2, TopLet(s, t1, e)))

  | Let(s, TUnknown, e1, e2) -> throw (NoReturnType s)

  | Let(s, t1, e1, e2) ->
      throwIfTypeUndefined env t1;

      if containsUnknown t1
        then throw (MissingTypeAnnotation (Let(s, t1, e1, e2)))
        else
          match typeOfExpr env e1 with
          | t2 when t1 = t2 -> typeOfExpr (Map.add s t2 env) e2
          | t2 -> throw (UnexpectedType(t1, t2, Let(s, t1, e1, e2)))

  | Fix (Abs(Untyped s, e))   -> throw (ParamNoType s)

  | Fix (Abs(Typed(s, t), e)) -> typeOfExpr (Map.add s t env) e

  | ProjRec(e, s1) ->
      match typeOfExpr env e with
      | TRecord(s2, m) ->
          match Map.tryFind s1 m with
          | Some t -> t
          | None   -> throw (RecordProjectionInvalidField s1)

      | t -> throw (RecordProjectionInvalidRecord t)

  | ListEmpty -> TList TAny

  | Tuple a -> TTuple (Array.map (typeOfExpr env) a)

  | ProjTup(e, i) ->
      match typeOfExpr env e with
      | TTuple a when 0 <= i && i < Array.length a -> a.[i]
      | TTuple a -> throw (TupleProjectionInvalidIndex i)
      | t -> throw (TupleProjectionInvalidTuple t)

  | DefRecord (s1, a) ->
      match Map.tryFind s1 env with
      | Some _ -> throw (TypeAlreadyDefined s1)
      | None   ->
          match tryFindDuplicate (Array.map fst a) with
          | None    -> TRecord(s1, Map.ofSeq a)
          | Some s2 -> throw (RecordDefinitionDuplicateField(s1, s2))

   | RecordLit(s1, a1) ->
       match Map.tryFind s1 env with
       | None -> throw (UndefinedType s1)
       | Some (TRecord (_, m)) ->
           let f (x, y) =
             match x with
             | Var s -> (s, y)
             | e     -> throw (RecordLiteralInvalidField (prettyStringCore e))

           let a2 = Map.toSeq m
           let xs = Seq.map fst a1
           let ys = Seq.map fst a2
           let x  = tryFindMissing   ys xs
           let y  = tryFindMissing   xs ys
           let z  = tryFindDuplicate xs

           match x, y, z with
           | Some s2, _      , _       -> throw (RecordLiteralMissingField s2)
           | _      , Some s2, _       -> throw (RecordLiteralInvalidField s2)
           | _      , _      , Some s2 -> throw (RecordLiteralDuplicateField s2)
           | None   , None   , None    ->
               let g ((s2, t1), (_, t2)) =
                 if t1 = t2
                   then None
                   else Some (s2, t1, t2)

               let a3 = Seq.map (fun (x, y) -> (x, typeOfExpr env y)) a1

               let a4 = Seq.zip (Seq.sortBy fst a2) (Seq.sortBy fst a3)

               match Seq.tryPick g a4 with
               | None              -> TRecord (s1, Map.ofSeq a3)
               | Some (s2, t1, t2) -> throw (RecordLiteralUnexpectedType (s2, t1, t2))

       | t -> failwithf "Error2 @ typeOfExpr: %A" t

  | e -> failwithf "Error1 @ typeOfExpr: %A" e



let typeOf (env : Map<string, Type>) e =
  try
    Type (typeOfExpr env e)
  with
    | TypeException err ->
        TypeError err



let testTypeOf env s =
  match parse s with
  | AST (Prgm es) ->
      for e in es do
         printfn "%A" (typeOf env (exprToCore e))
         // printfn "%A" (prettyStringCore (exprToCore e))

  | AST (Expr e1) ->
      printfn "%A" (typeOf env (exprToCore e1))

  | x -> failwithf "Error @ testTypeOf: %A" x

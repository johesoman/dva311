module Eval



open Lang
open Type
open Parser
open FSharpx.Text.Strings



module Vector = FSharpx.Collections.PersistentVector



// +++++++++
// + Error +
// +++++++++



type EvalError =
  | IfGuardNotBool     of Core
  | UndefinedVariable  of string
  | InvalidApplication of (Core * Core)
  | ReadInvalidFormat  of (string * string)
  | BopInvalidOperands of (Core * Op * Core)



exception EvalException of EvalError



let except (err: EvalError) =
  raise (EvalException err)



// ++++++++
// + Util +
// ++++++++



let log x =
  printfn "%A" x;
  x



let logp x =
  printfn "%A" x;
  ignore (System.Console.ReadLine());
  x



type ReplVerbosity =
  | AllSteps
  | JustResult



let freeVars =
  let rec go vars =
    function
    | Fix e -> go vars e

    | e when isLiteral e -> vars

    | RefLit e -> go vars e
    | DeRef  e -> go vars e

    | Var s              -> Set.add s vars
    | Index(s, i, _)     -> Set.add s vars

    | Abs(Typed (s, t), e) ->
        Set.remove s (go vars e)

    | Abs(Untyped s, e) ->
        Set.remove s (go vars e)

    | App(e1, e2) ->
        Set.union (go vars e1) (go vars e2)

    | Bop(e1, op, e2) ->
        Set.union (go vars e1) (go vars e2)

    | If(e1, e2, e3) ->
        Set.unionMany [ go vars e1
                      ; go vars e2
                      ; go vars e3
                      ]

    | RecordLit (_, a) ->
        Array.map (snd >> go vars) a
        |> Set.unionMany

    | Seq a ->
        let f acc x =
          Set.union acc (go vars x)

        Seq.fold f Set.empty a

    | ProjRec(e, _) -> go vars e
    | ProjTup(e, _) -> go vars e

    | Let(s, t, e1, e2) ->
        Set.union
          (go vars e1)
          (Set.remove s (go vars e2))

    | e -> failwithf "Error @ freeVars: %A" e

  go Set.empty >> Set.toList



let captureFreeVars env e1 =
  let f acc =
    function
    | (s2, Some(t, e2)) ->
        Let(s2, t, e2, acc)
    | (s2, None)    ->
        except (UndefinedVariable s2)

  let xs = freeVars e1

  List.map (fun x -> Map.tryFind x env) xs
  |> List.zip xs
  |> List.fold f e1



let mapExpr onIdx =
  let rec go c =
    function
    | Fix e -> Fix(go c e)

    | e when isLiteral e -> e

    | RefLit e -> RefLit (go c e)
    | DeRef  e -> DeRef  (go c e)

    | RecordLit (s, a) ->
        let f (x, y) = x, go c y
        RecordLit (s, Array.map f a)

    | Index(s, i, n)    -> onIdx c s i n

    | ProjTup(e, i)     -> ProjTup(go c e, i)

    | ProjRec(e, s)     -> ProjRec(go c e, s)

    | Abs(p, e)         -> Abs(p, go (c + 1) e)

    | App(e1, e2)       -> App(go c e1, go c e2)

    | Bop(e1, op, e2)   -> Bop (go c e1, op, go c e2)

    | If(e1, e2, e3)    -> If(go c e1, go c e2, go c e3)

    | Seq a             -> Seq (Array.map (go c) a)

    | Let(s, t, e1, e2) -> Let(s, t, go c e1, go (c + 1) e2)


    | e -> failwithf "Error @ mapExpr: %A" e

  go 0



let shiftExpr d =
  let onIdx c s i n =
    if c <= i
      then Index(s, i + d, n + d)
      else Index(s, i    , n + d)

  mapExpr onIdx



let substituteExpr e1 e2 =
  let onIdx c s i n =
    if c = i
      then shiftExpr (c + 1) e1
      else Index(s, i, n)

  mapExpr onIdx e2
  |> shiftExpr (-1)



let toNameless : Core -> Core =
  let rec go ss =
    function
    | Var s ->
        match List.tryFindIndex ((=) s) ss with
        | Some i -> Index(s, i, List.length ss)
        | None   -> except (UndefinedVariable s)

    | Fix e -> Fix(go ss e)

    | e when isLiteral e -> e

    | RefLit e -> RefLit (go ss e)
    | DeRef  e -> DeRef  (go ss e)

    | Seq a -> Seq (Array.map (go ss) a)

    | ProjTup(e, i)         -> ProjTup (go ss e, i)

    | ProjRec(e, s)         -> ProjRec (go ss e, s)

    | App (e1, e2)          -> App (go ss e1, go ss e2)

    | Bop (e1, op, e2)      -> Bop (go ss e1, op, go ss e2)

    | Abs (Untyped s, e)    -> Abs (Untyped s, go (s :: ss) e)

    | Abs (Typed (s, t), e) -> Abs (Typed (s, t), go (s :: ss) e)

    | If  (e1, e2, e3)      -> If  (go ss e1, go ss e2, go ss e3)

    | Let (s, t, e1, e2)    -> Let (s, t, go ss e1, go (s :: ss) e2)

    | RecordLit (s, es) ->
        let f (x, y) = x, go ss y
        (RecordLit (s, Array.map f es))

    | e -> failwithf "Error @ toNameless: %A" e

  go []



// ++++++++++++++
// + Evaluation +
// ++++++++++++++



type Env = Map<string, Type * Core>



type TypeEnv = Map<string, Type>



let mkTypeEnv : Env -> TypeEnv =
  Map.map (fun _ (x, _) -> x)



type Store = FSharpx.Collections.PersistentVector<Core>



type State =
  { env   : Env
  ; store : Store
  }



let stateEmpty : State =
  { env   = Map.empty
  ; store = Vector.empty
  }



let storeAlloc (x : Core) (st : State) =
  (Vector.length st.store, {st with store = Vector.conj x st.store})



let storeFetch (i : int) (st : State) = st.store.[i]



let storeUpdate (i : int) (x : Core) (st : State) =
  {st with store = Vector.update i x st.store}



let envAdd k v (st : State) = {st with env = Map.add k v st.env}



let allocRefs =
  let rec go st1 =
    function
    | Var s -> Var s, st1

    | e when isLiteral e -> e, st1

    | Index(s, i, n) -> Index (s, i, n), st1

    | Seq a1 ->
        let f (a2, st2) e1 =
          let e2, st3 = go st2 e1
          (Array.append a2 [|e2|], st3)

        let a2, st2 = Seq.fold f ([||], st1) a1
        Seq a2, st2

    | Fix e1 ->
        let e2, st2 = go st1 e1
        Fix e2, st2

    | RecordLit (s, a1) ->
        let f (a2, st2) (x, e1) =
          let e2, st3 = go st2 e1
          (Array.append a2 [|x, e2|], st3)

        let a2, st2 = Seq.fold f ([||], st1) a1
        RecordLit (s, a2), st2

    | RefLit e1 ->
        let e2, st2 = go st1 e1
        let i , st3 = storeAlloc e2 st2
        Ref i , st3

    | DeRef e1 ->
        let e2, st2 = go st1 e1
        DeRef e2, st2

    | ProjTup(e1, i) ->
        let e2, st2 = go st1 e1
        ProjTup (e2, i), st2

    | ProjRec (e1, s) ->
        let e2, st2 = go st1 e1
        ProjRec (e2, s), st2

    | Abs (p, e1) ->
        let e2, st2 = go st1 e1
        Abs(p, e2), st2

    | App(e1, e2) ->
        let e3, st2 = go st1 e1
        let e4, st3 = go st2 e2
        App(e3, e4), st3

    | Bop(e1, op, e2)   ->
        let e3, st2 = go st1 e1
        let e4, st3 = go st2 e2
        Bop (e3, op, e4), st3

    | If(e1, e2, e3) ->
        let e4, st2 = go st1 e1
        let e5, st3 = go st2 e2
        let e6, st4 = go st3 e3
        If(e4, e5, e6), st4

    | Let(s, t, e1, e2) ->
        let e3, st2 = go st1 e1
        let e4, st3 = go st2 e2
        Let(s, t, e3, e4), st3

    | e -> failwithf "Error @ allocRefs: %A" e

  go


exception NoRuleApplies of Core * State



let rec evalBop (st1 : State) =
  function
  | Bop(v1, op, v2) when isLiteral v1 && isLiteral v2 ->
      match (v1, op, v2) with
      // Int -> Int -> Int
      | (Int x, Add, Int y) -> x +  y |> Int, st1
      | (Int x, Sub, Int y) -> x -  y |> Int, st1
      | (Int x, Mul, Int y) -> x *  y |> Int, st1
      | (Int x, Div, Int y) -> x /  y |> Int, st1

      // Int -> Int -> Bool
      | (Int x, Eq , Int y) -> x =  y |> Bool, st1
      | (Int x, Ne , Int y) -> x <> y |> Bool, st1
      | (Int x, Lt , Int y) -> x <  y |> Bool, st1
      | (Int x, Le , Int y) -> x <= y |> Bool, st1
      | (Int x, Gt , Int y) -> x >  y |> Bool, st1
      | (Int x, Ge , Int y) -> x >= y |> Bool, st1

      // Bool -> Bool -> Bool
      | (Bool x, Or , Bool y) -> (x || y) |> Bool, st1
      | (Bool x, And, Bool y) -> (x && y) |> Bool, st1
      | (Bool x, Eq , Bool y) ->  x =  y  |> Bool, st1
      | (Bool x, Ne , Bool y) ->  x <> y  |> Bool, st1

      | (Ref  i, RefAsn,   x) -> Unit, storeUpdate i x st1

      // String -> String -> String
      | (String x, Add, String y) -> x + y |> Core.String, st1

      | _ -> except (BopInvalidOperands(v1, op, v2))

  | Bop(v, op, e1) when isLiteral v  ->
      let e2, st2 = evalExpr1 st1 e1
      Bop(v , op, e2), st2

  | Bop(e1, op, e2) ->
      let e3, st2 = evalExpr1 st1 e1
      Bop(e3, op, e2), st2

  | e -> failwithf "Error @ evalBop: %A" e



and evalExpr1 (st1 : State) =
  function
  | Bop _  as e1 -> evalBop st1 e1

  | DeRef (Ref i) ->
      match storeFetch i st1 with
      | e1 when isValue e1 -> e1, st1
      | e1 ->
          let e2, st2 = evalToValue st1 e1
          let     st3 = storeUpdate i e2 st2
          e2, st3

  | Fix (Abs(_, e1)) as e2 ->
      substituteExpr e2 e1, st1

  | App(Abs(_,e), v) when isValue v ->
      substituteExpr v e, st1

  | App(v, e1) when isValue v ->
      let e2, st2 = evalExpr1 st1 e1
      App(v , e2), st2

  | App(e1, e2) ->
      let e3, st2 = evalExpr1 st1 e1
      App(e3, e2), st2

  | Let(s, _, v, e) when isValue v ->
      substituteExpr v e, st1

  | Let(s, t, e1, e2) ->
      let e3, st2 = evalExpr1 st1 e1
      Let(s, t, e3, e2), st2

  | If(Bool true , e2, e3) -> e2, st1
  | If(Bool false, e2, e3) -> e3, st1

  | If(e1, e2, e3) ->
      let e4, st2 = evalExpr1 st1 e1
      If(e4, e2, e3), st2

  | RecordLit(s, a1) ->
      let f (a2, st2) (x, e1) =
        let e2, st3 = evalToValue st2 e1
        (Array.append a2 [|(x, e2)|], st3)

      Seq.fold f ([||], st1) a1
      |> (fun (a2, st2) -> (Record (s, Map.ofSeq a2), st2))

  | ProjRec(Record(_, fields), s) ->
      Map.find s fields, st1

  | ProjRec(e1, s) ->
      let e2, st2 = evalExpr1 st1 e1
      ProjRec (e2, s), st2

  | Seq a1 when 0 < Array.length a1 ->
      let f (a2, st2) e1 =
        let e2, st3 = evalToValue st2 e1
        (Array.append a2 [|e2|], st3)

      let a2, st2 = Seq.fold f ([||], st1) a1
      Array.last a2, st2

  | Tuple a1 ->
      let f (a2, st2) e1 =
        let e2, st3 = evalToValue st2 e1
        (Array.append a2 [|e2|], st3)

      Seq.fold f ([||], st1) a1
      |> (fun (a2, st2) -> (Tuple a2, st2))

  | ProjTup(Tuple a, i) -> a.[i], st1

  | ProjTup(e1, i) ->
      let e2, st2 = evalExpr1 st1 e1
      ProjTup(e2, i), st2

  | e -> raise (NoRuleApplies (e, st1))



and evalToValue st1 =
  function
  | v when isValue v -> v, st1
  | e1 ->
      let e2, st2 = evalExpr1 st1 e1
      evalToValue st2 e2



let printFirst : Core -> unit =
     prettyStringCore
  >> printfn "%s"



let printNext : Core -> unit =
      prettyStringCore
   >> toLines
   >> Seq.toArray
   >> (function
       | xs when Array.isEmpty xs -> printfn "{}"
       | xs ->
           printfn "  => %s" xs.[0];
           for x in xs.[1..] do
             printfn "     %s" x)



let evalExpr (whatToPrint : ReplVerbosity) =
  let rec driver isFirst st1 e1 =
    let maybePrintStep _ =
      match (whatToPrint, isFirst) with
      | (AllSteps, true ) -> printFirst e1
      | (AllSteps, false) -> printNext  e1
      | _ -> ()

    maybePrintStep();

    try
      let e2, st2 = evalExpr1 st1 e1
      driver false st2 e2
    with
      | NoRuleApplies (e2, st2) ->
          match whatToPrint with
          | AllSteps   -> Some st2
          | JustResult ->
              printfn "%s" (prettyStringCore e2);
              Some st2
      | EvalException err ->
          printfn "%A" err
          None

  let go st1 e1 =
    let e2 = exprToCore e1

    match typeOf (mkTypeEnv st1.env) e2 with
    | Type _ ->
        let e3, st2 = allocRefs st1 e2

        captureFreeVars st2.env e3
        |> toNameless
        |> driver true st2

    | TypeError err ->
        printfn "%A" err;
        None

  go





let evalTop (st1 : State) : Core -> State option =
  function
  | TopLet(s, t1, e1) as e2 ->
      match typeOf (mkTypeEnv st1.env) e2 with
      | Type t2 ->
          printfn "val %s : %s" s (prettyStringType t2);

          let e3, st2 = allocRefs st1 e1

          captureFreeVars st2.env e3
          |> (fun x -> Some (envAdd s (t2, x) st2))

      | TypeError err ->
          printfn "%A" err;
          None

  | DefRecord (s, _) as e ->
      match typeOf (mkTypeEnv st1.env) e with
      | Type t ->
         printfn "%s" (prettyStringType t);
         Some (envAdd s (t, Unit) st1)

      | TypeError err ->
          printfn "%A" err;
          None

  | e -> failwithf "Error @ evalTop: %A" e



let evalPrgm (st1 : State) =
  let f acc x =
    match acc with
    | None     -> None
    | Some st2 -> evalTop st2 x

  List.map exprToCore
  >> List.fold f (Some st1)



let eval (whatToPrint : ReplVerbosity) (s : string) : State option -> State option  =
  function
  | None    -> None
  | Some st ->
      match parse s with
      | AST (Prgm es) -> evalPrgm st es
      | AST (Expr e)  -> evalExpr whatToPrint st e
      | AST Empty     -> printfn "{}"; None
      | Error s       -> printfn "%s" s; None



let init : State option = Some stateEmpty



let wait (x: 'a) : 'a =
  printfn "waiting...";
  ignore (System.Console.ReadLine());
  x



let stop : 'a -> unit = ignore



let test1 _ =
     init
  |> eval JustResult "type Base  = (x : Int)"
  |> eval JustResult "type Thing = (x : Int, y : Int)"
  |> eval JustResult "type Other = (x : Int, y : Int, z : Int)"

  |> eval JustResult "let add (t : Thing) : Int = t.x + t.y"
  |> eval JustResult "let f (o : Other) : Other = \
                        Other(x = o.x, y = o.y, z = add o)"
  |> eval AllSteps   "f Other(x = 1300, y = 37, z = 0)"

  |> eval JustResult "let g (b : Base) : Thing = Thing(x = 0, y = b.x)"
  |> eval JustResult "let h (f : Thing -> Base) : Int = \
                        (f Thing(x = 1337, y = 0)).x"
  |> eval AllSteps   "h g"

  |> stop

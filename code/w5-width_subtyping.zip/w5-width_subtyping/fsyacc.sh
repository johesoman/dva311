#!/usr/bin/env bash

mono /home/mrj/.nuget/packages/fslexyacc/7.0.6/build/fsyacc.exe ParserImpl.fsy
sed -i "1i module ParserImpl" ParserImpl.fs

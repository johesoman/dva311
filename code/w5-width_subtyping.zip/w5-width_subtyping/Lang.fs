module Lang



#nowarn "40" // I don't understand why I need this but I do.



open PPrint
open FSharpx.Collections



let parensIf =
  function
  | false -> id
  | true  -> parens



type Type =
  | TAny
  | TUnit
  | TInt
  | TBool
  | TString
  | TUnknown
  | TRef        of Type
  | TList       of Type
  | TUser       of string
  | TFun        of Type []
  | TTuple      of Type []
  | TNamedRow   of string * Type
  | TNamedTuple of (string * Type) []
  | TMixedTuple
  | TRecord     of string * Map<string, Type>



let rec prettyType =
  function
  | TUnit     -> txt "()"
  | TInt      -> txt "Int"
  | TBool     -> txt "Bool"
  | TString   -> txt "String"
  | TUser s -> txt s

  | TRef (TFun a) -> chr '&' <^> parens (prettyType (TFun a))
  | TRef t        -> chr '&' <^> prettyType t

  | TRecord(s, m) ->
      let a  = Array.ofSeq (Map.toSeq m)
      let t  = a.[0]
      let ts = a.[1..]

      let f (x, y) = txt x <+> chr ':' <+> prettyType y

      Array.map (fun x -> chr ',' <+> f x) ts
      |> (fun ts' -> Array.append [|f t|] ts')
      |> hcat
      |> parens
      |> (fun x -> txt "type" <+> txt s <+> chr '=' <+> x)

  | TFun ts ->
      let f =
        function
        | TFun(_)    as t -> parens (prettyType t)
        | t               -> prettyType t

      Array.map f ts
      |> Seq.intersperse (txt "->")
      |> hsep

  | TTuple a when not (Array.isEmpty a) ->
      let t  = a.[0]
      let ts = a.[1..]

      Array.map prettyType ts
      |> Array.map ((<+>) (chr ','))
      |> (fun ts' -> Array.append [|prettyType t|] ts')
      |> hcat
      |> parens

  | TList t   ->
      chr '[' <^> prettyType t
              <^> chr ']'

  | t -> failwithf "Error @ prettyType: %A" t



type Param =
  | Untyped of string
  | Typed   of string * Type



let paramToType =
  function
  | Untyped s   -> TUnknown
  | Typed(s, t) -> t



let prettyParam =
  function
  | Untyped s     -> txt s
  | Typed(s, t) -> txt s <+> chr ':' <+> prettyType t |> parens



let prettyParamList (ps : Param list) =
  match ps with
  | [] -> empty
  | _  -> Seq.map prettyParam ps |> vsep |> align



type Op =
  | Add
  | Sub
  | Mul
  | Div
  | Eq
  | Ne
  | Lt
  | Gt
  | Le
  | Ge
  | Or
  | And
  | Cons
  | Concat
  | RefAsn



let prettyOp =
  function
  | Add    -> chr '+'
  | Sub    -> chr '-'
  | Mul    -> chr '*'
  | Div    -> chr '/'
  | Eq     -> txt "=="
  | Ne     -> txt "<>"
  | Lt     -> chr '<'
  | Gt     -> chr '>'
  | Le     -> txt "<="
  | Ge     -> txt ">="
  | Or     -> txt "||"
  | And    -> txt "&&"
  | Cons   -> txt "::"
  | Concat -> chr '@'
  | RefAsn -> txt ":="



type Core =
  | Unit
  | Int       of int
  | Bool      of bool
  | Fix       of Core
  | Var       of string
  | String    of string
  | Ref       of int
  | DeRef     of Core
  | RefLit    of Core
  | App       of Core * Core
  | Abs       of Param * Core
  | ProjTup   of Core * int
  | ProjAgg   of Core * Core
  | ProjRec   of Core * string
  | Bop       of Core * Op * Core
  | Record    of string * Map<string, Core>
  | RecordLit of string * (string * Core) []
  | ListEmpty
  | DefADT
  | DefRecord of string * (string * Type) []
  | Tuple     of Core []
  | Seq       of Core []
  | Index     of string * int * int
  | If        of Core * Core * Core
  | TopLet    of string * Type * Core
  | Let       of string * Type * Core * Core



type Expr =
  | EUnit
  | EFix               of Expr
  | EInt               of int
  | EBool              of bool
  | EVar               of string
  | EString            of string
  | EUop               of Op * Expr
  | EApp               of Expr * Expr
  | ESeq               of Expr []
  | EBop               of Expr * Op * Expr
  | ELambda            of Param [] * Expr
  | EIf                of Expr * Expr * Expr
  | ERef               of int
  | EDeRef             of Expr
  | ERefLit            of Expr
  | EProjTup           of Expr * int
  | EProjAgg           of Expr * Expr
  | EProjRec           of Expr * string
  | ERecord            of string * (string * Expr) []
  | EADT               of string * Expr []
  | ESet               of Expr []
  | EDefADT
  | EDefRecord         of string * (string * Type) []
  | ESetEmpty
  | EMap               of (Expr * Expr) []
  | EMapEmpty
  | EList              of Expr []
  | EListEmpty
  | ETuple             of Expr []
  | EMapping           of Expr * Expr
  | ENamedRow          of string * Expr
  | EMappingSeq        of (Expr * Expr) []
  | EMappingTuple      of (string * Expr) []
  | EMixedMappingSeq
  | EMixedMappingTuple
  | ETopLet            of string * Param [] * Type * Expr
  | ETopLetRec         of string * Param [] * Type * Expr
  | ELet               of string * Param [] * Type * Expr * Expr
  | ELetRec            of string * Param [] * Type * Expr * Expr



let isMapping =
  function
  | EMapping _ -> true
  | _          -> false



let unMap =
  function
  | EMapping(e1, e2) -> (e1, e2)
  | e                -> failwithf "Error @ unMap: %A" e



let isNamedRow =
  function
  | EMapping(EVar _, _) -> true
  | _                   -> false



let unRow =
  function
  | EMapping(EVar s, e) -> (s, e)
  | e                   -> failwithf "Error @ unRow: %A" e



let isLiteral =
  function
  | Unit        -> true
  | Int _       -> true
  | Bool _      -> true
  | String _    -> true
  | Record _    -> true
  | Tuple  _    -> true
  | ListEmpty   -> true
  | Ref _       -> true
  | _           -> false



let isValue =
  function
  | e when isLiteral e -> true
  | Abs _              -> true
  | _                  -> false



let isAtom =
  function
  | Unit      -> true
  | Int _     -> true
  | Bool _    -> true
  | Var _     -> true
  | Index _   -> true
  | String _  -> true
  | _         -> false



let isAtomExpr =
  function
  | EUnit      -> true
  | EInt _     -> true
  | EBool _    -> true
  | EVar _     -> true
  | EString _  -> true
  | e          -> false



let precedence =
  function
  | ESeq       _       -> 1
  | ETuple     _       -> 2
  | ELet       _       -> 3
  | ELetRec    _       -> 3
  | ETopLet    _       -> 3
  | ETopLetRec _       -> 3
  | ELambda    _       -> 3
  | EIf        _       -> 3
  | EBop(_, RefAsn, _) -> 3
  | EBop(_, Or , _)    -> 4
  | EBop(_, And, _)    -> 5
  | EBop(_, Eq , _)    -> 6
  | EBop(_, Ne , _)    -> 6
  | EBop(_, Lt , _)    -> 6
  | EBop(_, Gt , _)    -> 6
  | EBop(_, Le , _)    -> 6
  | EBop(_, Ge , _)    -> 6
  | EBop(_, Concat, _) -> 7
  | EBop(_, Cons, _)   -> 8
  | EBop(_, Add, _)    -> 9
  | EBop(_, Sub, _)    -> 9
  | EBop(_, Mul, _)    -> 10
  | EBop(_, Div, _)    -> 10
  | EApp       _       -> 11
  | EDeRef     _       -> 11
  | ERefLit    _       -> 11
  | EProjRec   _       -> 12
  | EProjTup   _       -> 12
  | EProjAgg   _       -> 12
  | EFix       _       -> 13
  | EVar       _       -> 13
  | EInt       _       -> 13
  | EBool      _       -> 13
  | EString    _       -> 13
  | ERecord    _       -> 13
  | EList      _       -> 13
  | EListEmpty _       -> 13
  | ERef       _       -> 13
  | EUnit              -> 13
  | e -> failwithf "Error @ precedence: %A" e



let prettySig s ps =
  let go p =
    function
    | TUnknown ->
        p @ [chr '=']
    | t ->
        p @ [chr ':'; prettyType t; chr '=']

  let p = txt s :: List.map prettyParam ps

  go p >> hsep



let rec prettyTopLet s ps t e1 =
  let x = prettySig s ps t

  let y =
    if isAtomExpr e1
      then empty <+> prettyExpr e1
      else line  <^> prettyExpr e1 |> nest 2

  x <^> y



and prettyLet s ps t e1 e2 =
  let x = line <^> txt "in" <+> (prettyExpr e2 |> nest 3)

  prettyTopLet s ps t e1 <^> x



and prettyExpr =
  let rec go p1 e =
    let p2 = precedence e

    parensIf (p2 < p1) <|
    match e with
    | EUnit       -> txt "()"
    | EVar  x     -> txt x
    | EInt  x     -> txt (sprintf "%d" x)
    | EBool false -> txt "False"
    | EBool true  -> txt "True"

    | EDeRef  e -> chr '!' <^> go p2 e
    | ERefLit e -> chr '&' <^> go p2 e
    | ERef    i -> txt "<loc:" <+> txt (sprintf "%d" i) <^> chr '>'

    | EFix e ->
        txt "fix" <+> go p2 e

    | EString s ->
        chr '"' <^> txt s <^> chr '"'

    | ELet(s, ps, t, e1, e2) ->
        txt "let" <+> prettyLet s (List.ofArray ps) t e1 e2

    | ELetRec(s, ps, t, e1, e2) ->
        txt "rec" <+> prettyLet s (List.ofArray ps) t e1 e2

    | ELambda(ps, e1) ->
        let sgn =
          Array.append
            (Array.map prettyParam ps)
            [|txt "->"|]
          |> vsep
          |> align
          |> group

        txt "fun" <.> sgn
                  <.> go p2 e1
        |> gnest 2

    | EApp(e1, e2) ->
        go p2 e1 <.> go p2 e2
        |> group

    | EIf(e1, e2, e3) ->
        let x = txt "if" <+> go p2 e1

        let y = line <^> txt "then" <^> (line <^> go p2 e2 |> gnest 2) |> nest 2

        let z = line <^> txt "else" <^> (line <^> go p2 e3 |> gnest 2) |> nest 2

        x <^> y <^> z

    | EBop(e1, op, e2) ->
        go p2 e1 <+> prettyOp op
                 <.> go p2 e2
        |> group

    | ESeq a when 2 <= Array.length a ->
        let es = a.[0 .. Array.length a - 2]
        let e  =
          match Array.last a with
          | EUnit -> [||]
          | e     -> [|go p2 e|]

        Array.map (fun x -> go p2 x <^> chr ';') es
        |> (fun x -> Array.append x e)
        |> vsep

    | ETuple a when 2 <= Array.length a ->
        let es = a.[0 .. Array.length a - 2]
        let e  = Array.last a

        Array.map (fun x -> go p2 x <^> chr ',') es
        |> (fun x -> Array.append x [|go p2 e|])
        |> hsep

     | ERecord(s, a1) when not (Array.isEmpty a1) ->
         let f (x, y) = txt x <+> chr '=' <+> prettyExpr y

         match Array.map f a1, Array.length a1 with
         | a2, n when n = 1 -> txt s <^> parens a2.[0]
         | a2, n ->
             let es = a2.[0 .. Array.length a2 - 2]
             let e  = Array.last a2

             Array.map (fun x -> x <^> chr ',') es
             |> (fun x -> Array.append x [|e|])
             |> hsep
             |> parens
             |> (fun x -> txt s <^> x)

    | EListEmpty -> txt "[]"

    | EList a when Array.isEmpty a -> txt "[]"

    | EList a1 ->
        match Array.map prettyExpr a1, Array.length a1 with
        | a2, n when n = 1 -> brackets a2.[0]
        | a2, n ->
            let es = a2.[0 .. Array.length a2 - 2]
            let e  = Array.last a2

            Array.map (fun x -> x <^> chr ';') es
            |> (fun x -> Array.append x [|e|])
            |> hsep
            |> brackets

    | ETopLet(s, ps, t, e) ->
        txt "let" <+> prettyTopLet s (List.ofArray ps) t e

    | ETopLetRec(s, ps, t, e) ->
        txt "rec" <+> prettyTopLet s (List.ofArray ps) t e

    | EProjRec (e , s)  -> go p2 e <^> chr '.' <^> txt s
    | EProjTup (e , i)  -> go p2 e <^> chr '.' <^> txt (sprintf "%d" i)
    | EProjAgg (e1, e2) -> go p2 e <^> chr '[' <^> prettyExpr e2 <^> chr ']'

    | _ -> failwithf "Error @ prettyExpr: %A" e

  go 0



let rec coreToExpr =
  function
  | Unit           -> EUnit
  | Int x          -> EInt x
  | Var s          -> EVar s
  | Index(s, _, _) -> EVar s
  | Bool x         -> EBool x
  | String s       -> EString s

  | DeRef  e -> EDeRef  (coreToExpr e)
  | RefLit e -> ERefLit (coreToExpr e)

  | Ref i    -> ERef i

  | Bop(e1, op, e2) ->
      EBop(coreToExpr e1, op, coreToExpr e2)

  | App(e1, e2) ->
      EApp(coreToExpr e1, coreToExpr e2)

  | Abs(p, e1) ->
      match coreToExpr e1 with
      | ELambda(ps, e2) -> ELambda(Array.append [|p|] ps, e2)
      | e2              -> ELambda([|p|]    , e2)

  | Let(s, t, e1, e2) ->
      match (coreToExpr e1, coreToExpr e2) with
      | (ELambda(ps, e3), e4) -> ELet(s, ps, t, e3, e4)
      | (e3             , e4) -> ELet(s, [||], t, e3, e4)

  | TopLet(s, t, e1) ->
      match coreToExpr e1 with
      | ELambda(ps, e2) -> ETopLet(s, ps, t, e2)
      | e2              -> ETopLet(s, [||], t, e2)

  | If(e1, e2, e3) ->
      EIf(coreToExpr e1, coreToExpr e2, coreToExpr e3)

  | Fix e -> EFix (coreToExpr e)

  | Tuple a ->
      ETuple(Array.map coreToExpr a)

  | Record(s, m) ->
      Map.toArray m
      |> Array.map (fun (x, y) -> (x, coreToExpr y))
      |> (fun x -> ERecord(s, x))

  | RecordLit (s, a) ->
      Array.map (fun (x, y) -> (x, coreToExpr y)) a
      |> (fun x -> ERecord(s, x))

  | ProjTup (e, i) -> EProjTup(coreToExpr e, i)

  | ProjRec (e, s) -> EProjRec(coreToExpr e, s)

  | ListEmpty -> EListEmpty

  | Core.Seq a ->
      ESeq(Array.map coreToExpr a)

  | DefRecord(s, a) -> EDefRecord(s, a)

  | e -> failwithf "Error @ coreToExpr: %A" e



let rec exprToCore =
  function
  | EUnit      -> Unit
  | EInt x     -> Int x
  | EVar s     -> Var s
  | EBool x    -> Bool x
  | EString s  -> String s

  | EDeRef  e -> DeRef  (exprToCore e)
  | ERefLit e -> RefLit (exprToCore e)

  | EBop(e1, op, e2) ->
      Bop(exprToCore e1, op, exprToCore e2)

  | EApp(e1, e2) ->
      App(exprToCore e1, exprToCore e2)

  | ELambda(ps, e) ->
      exprToCore e
      |> Array.foldBack (fun x y -> Abs(x, y)) ps

  | ELet(s1, ps1, t1, e1, e2) ->
      match exprToCore (ETopLet(s1, ps1, t1, e1)) with
      | TopLet(s2, t2, e3) ->
          Let(s2, t2, e3, exprToCore e2)

      | e -> failwithf "Error2 @ exprToCore: %A" e

  | ELetRec(s1, ps1, t1, e1, e2) ->
      match exprToCore (ETopLetRec(s1, ps1, t1, e1)) with
      | TopLet(s2, t2, e3) ->
          Let(s2, t2, e3, exprToCore e2)

      | e -> failwithf "Error3@ exprToCore: %A" e

  | ETopLet(s, [||], t1, e) ->
      TopLet(s, t1, exprToCore e)

  | ETopLet(s, ps, t1, e) ->
      let t2 = TFun (Array.append (Array.map paramToType ps) [|t1|])
      TopLet(s, t2, exprToCore (ELambda(ps, e)))

  | ETopLetRec(s1, ps, t1, e1) ->
      let t2 =
        match ps with
        | [||] -> t1
        | _    -> TFun (Array.append (Array.map paramToType ps) [|t1|])

      let p =
        match t2 with
        | TUnknown -> Untyped s1
        | _        -> Typed(s1, t2)

      let e2 = exprToCore (ELambda(ps, e1))

      TopLet(s1, t2, Fix (Abs(p, e2)))

  | EIf(e1, e2, e3) ->
      If(exprToCore e1, exprToCore e2, exprToCore e3)

  | ETuple a ->
      Tuple(Array.map exprToCore a)

  | ESeq a ->
      Core.Seq(Array.map exprToCore a)

  | ERecord(s, a) ->
      Array.map (fun (x, y) -> (x, exprToCore y)) a
      |> (fun x -> RecordLit(s, x))

  | EListEmpty -> ListEmpty

  | EList a ->
      let f e acc = Bop(exprToCore e, Cons, acc)

      Array.foldBack f a ListEmpty

  | EDefRecord(s, a) -> DefRecord(s, a)

  | EProjTup(e, i) -> ProjTup(exprToCore e, i)

  | EProjRec(e, s) -> ProjRec(exprToCore e, s)

  | e -> failwithf "Error1 @ exprToCore: %A" e



let mapOtherOnLast f g =
  let rec go =
    function
    | []    -> []
    | [x]   -> [g x]
    | x::xs -> f x :: go xs

  Seq.toList >> go >> Seq.ofList



type AST =
  | Prgm of Expr list
  | Expr of Expr
  | Empty



let prettyAST =
  function
  | Prgm [] -> txt "{}"
  | Prgm ts ->
      let withLine t = prettyExpr t <^> chr '\n'
      vsep (mapOtherOnLast withLine prettyExpr ts)

  | Expr e  -> prettyExpr e

  | Empty   -> txt "{}"



let prettyRender = render (Some 80)



let prettyStringAST =
     prettyAST
  >> prettyRender



let prettyStringASTWith n =
     prettyAST
  >> render (Some n)



let prettyStringExpr =
     prettyExpr
  >> prettyRender



let prettyStringCore =
     coreToExpr
  >> prettyExpr
  >> prettyRender



let prettyStringType =
     prettyType
  >> prettyRender

#!/usr/bin/env bash

mono packages/FsLexYacc/build/fslex.exe --unicode LexerImpl.fsl

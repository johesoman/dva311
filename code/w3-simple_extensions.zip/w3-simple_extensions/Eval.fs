module Eval


open Lang
open Type
open Parser
open FSharpx.Text.Strings



// +++++++++
// + Error +
// +++++++++



type EvalError =
  | IfGuardNotBool     of Core
  | UndefinedVariable  of string
  | InvalidApplication of (Core * Core)
  | ReadInvalidFormat  of (string * string)
  | BopInvalidOperands of (Core * Op * Core)



exception EvalException of EvalError



let except (err: EvalError) =
  raise (EvalException err)



// ++++++++
// + Util +
// ++++++++



let pp x =
  printfn "pp> %A" x;
     System.Console.ReadLine()
  |> ignore



type ReplVerbosity =
  | AllSteps
  | JustResult



let freeVars =
  let rec go vars =
    function
    | Fix e -> go vars e

    | e when isLiteral e -> vars

    | Var s              -> Set.add s vars
    | Index(s, i, _)     -> Set.add s vars

    | Abs(Typed (s, t), e) ->
        Set.remove s (go vars e)

    | Abs(Untyped s, e) ->
        Set.remove s (go vars e)

    | App(e1, e2) ->
        Set.union (go vars e1) (go vars e2)

    | Bop(e1, op, e2) ->
        Set.union (go vars e1) (go vars e2)

    | If(e1, e2, e3) ->
        Set.unionMany [ go vars e1
                      ; go vars e2
                      ; go vars e3
                      ]

    | ProjRec(e, _) -> go vars e
    | ProjTup(e, _) -> go vars e

    | Let(s, t, e1, e2) ->
        Set.union
          (go vars e1)
          (Set.remove s (go vars e2))

    | e -> failwithf "Error @ freeVars: %A" e

  go Set.empty >> Set.toList



let captureFreeVars env e1 =
  let f acc =
    function
    | (s2, Some(t, e2)) ->
        Let(s2, t, e2, acc)
    | (s2, None)    ->
        except (UndefinedVariable s2)

  let xs = freeVars e1

  List.map (fun x -> Map.tryFind x env) xs
  |> List.zip xs
  |> List.fold f e1



let mapExpr onIdx =
  let rec go c =
    function
    | Fix e -> Fix(go c e)

    | e when isLiteral e -> e

    | Index(s, i, n)    -> onIdx c s i n

    | ProjTup(e, i)     -> ProjTup(go c e, i)

    | ProjRec(e, s)     -> ProjRec(go c e, s)

    | Abs(p, e)         -> Abs(p, go (c + 1) e)

    | App(e1, e2)       -> App(go c e1, go c e2)

    | Bop(e1, op, e2)   -> Bop(go c e1, op, go c e2)

    | If(e1, e2, e3)    -> If(go c e1, go c e2, go c e3)

    | Let(s, t, e1, e2) -> Let(s, t, go c e1, go (c + 1) e2)

    | e -> failwithf "Error @ mapExpr: %A" e

  go 0



let shiftExpr d =
  let onIdx c s i n =
    if c <= i
      then Index(s, i + d, n + d)
      else Index(s, i    , n + d)

  mapExpr onIdx



let substituteExpr e1 e2 =
  let onIdx c s i n =
    if c = i
      then shiftExpr (c + 1) e1
      else Index(s, i, n)

  mapExpr onIdx e2
  |> shiftExpr (-1)



let toNameless : Core -> Core =
  let rec go ss =
    function
    | Var s ->
        match List.tryFindIndex ((=) s) ss with
        | Some i -> Index(s, i, List.length ss)
        | None   -> except (UndefinedVariable s)

    | Fix e -> Fix(go ss e)

    | e when isLiteral e -> e

    | ProjTup(e, i)         -> ProjTup (go ss e, i)

    | ProjRec(e, s)         -> ProjRec (go ss e, s)

    | App (e1, e2)          -> App (go ss e1, go ss e2)

    | Bop (e1, op, e2)      -> Bop (go ss e1, op, go ss e2)

    | Abs (Typed (s, t), e) -> Abs (Typed (s, t), go (s :: ss) e)

    | Abs (Untyped s, e)    -> Abs (Untyped s, go (s :: ss) e)

    | Let (s, t, e1, e2)    -> Let (s, t, go ss e1, go (s :: ss) e2)

    | If  (e1, e2, e3)      -> If  (go ss e1, go ss e2, go ss e3)

    | e -> failwithf "Error @ toNameless: %A" e

  go []



// ++++++++++++++
// + Evaluation +
// ++++++++++++++



exception NoRuleApplies of Core



let rec evalBop =
  function
  | Bop(v1, op, v2) when isLiteral v2 ->
      match (v1, op, v2) with
      // Int -> Int -> Int
      | (Int x, Add, Int y) -> x +  y |> Int
      | (Int x, Sub, Int y) -> x -  y |> Int
      | (Int x, Mul, Int y) -> x *  y |> Int
      | (Int x, Div, Int y) -> x /  y |> Int

      // Int -> Int -> Bool
      | (Int x, Eq , Int y) -> x =  y |> Bool
      | (Int x, Ne , Int y) -> x <> y |> Bool
      | (Int x, Lt , Int y) -> x <  y |> Bool
      | (Int x, Le , Int y) -> x <= y |> Bool
      | (Int x, Gt , Int y) -> x >  y |> Bool
      | (Int x, Ge , Int y) -> x >= y |> Bool

      // Bool -> Bool -> Bool
      | (Bool x, Or , Bool y) -> (x || y) |> Bool
      | (Bool x, And, Bool y) -> (x && y) |> Bool
      | (Bool x, Eq , Bool y) ->  x =  y  |> Bool
      | (Bool x, Ne , Bool y) ->  x <> y  |> Bool

      // String -> String -> String
      | (String x, Add, String y) -> x + y |> Core.String

      | _ -> except (BopInvalidOperands(v1, op, v2))

  | Bop(v, op, e) when isLiteral v  ->
      Bop(v, op, evalExpr1 e)

  | Bop(e1, op, e2) ->
      Bop(evalExpr1 e1, op, e2)

  | e -> failwithf "Error @ evalBop: %A" e



and evalExpr1 =
  function
  | Bop _  as e -> evalBop e

  | Fix (Abs(p, e1)) as e2 ->
      substituteExpr e2 e1

  | App(Abs(_,v1), v2) when isValue v2 ->
      substituteExpr v2 v1

  | App(v, e) when isValue v ->
      App(v, evalExpr1 e)

  | App(e1, e2) ->
      App(evalExpr1 e1, e2)

  | Let(s, _, v, e) when isValue v ->
      substituteExpr v e

  | Let(s, t, e1, e2) ->
      Let(s, t, evalExpr1 e1, e2)

  | If(Bool true , e2, e3) -> e2
  | If(Bool false, e2, e3) -> e3

  | If(v, e1, e2) when isValue v ->
      except (IfGuardNotBool(If(v, e1, e2)))

  | If(e1, e2, e3) ->
      If(evalExpr1 e1, e2, e3)

  | RecordLit(s, a) ->
      Seq.map (fun (x, y) -> (x, evalToValue y)) a
      |> Map.ofSeq
      |> (fun x -> Record(s, x))

  | ProjRec(Record(_, fields), s) ->
      Map.find s fields

  | ProjRec(e, s) ->
      ProjRec (evalExpr1 e, s)

  | Tuple a ->
      Tuple (Array.map evalToValue a)

  | ProjTup(Tuple a, i) -> a.[i]

  | ProjTup(e, i) ->
      ProjTup(evalExpr1 e, i)

  | e -> raise (NoRuleApplies e)



and evalToValue =
  function
  | v when isValue v -> v
  | e -> evalToValue (evalExpr1 e)



let printFirst : Core -> unit =
     prettyStringCore
  >> printfn "%s"



let printNext : Core -> unit =
      prettyStringCore
   >> toLines
   >> Seq.toArray
   >> (function
       | xs when Array.isEmpty xs -> printfn "{}"
       | xs ->
           printfn "  => %s" xs.[0];
           for x in xs.[1..] do
             printfn "     %s" x)



type Env = Map<string, Type * Core>



let mkTypeEnv =
  Map.map (fun _ (x, _) -> x)



let evalExpr (whatToPrint : ReplVerbosity) (env : Env) =
  let rec driver isFirst e =
    let maybePrintStep _ =
      match (whatToPrint, isFirst) with
      | (AllSteps, true ) -> printFirst e
      | (AllSteps, false) -> printNext  e
      | _ -> ()

    maybePrintStep();

    try
      driver false (evalExpr1 e)
    with
      | NoRuleApplies e2 ->
          match whatToPrint with
          | AllSteps   -> Some env
          | JustResult ->
              printfn "%s" (prettyStringCore e2);
              Some env
      | EvalException err ->
          printfn "%A" err
          None

  let go e1 =
    let e2 = exprToCore e1

    match typeOf (mkTypeEnv env) e2 with
    | Type _ ->
        captureFreeVars env e2
        |> toNameless
        |> driver true
        |> ignore
        Some env

    | TypeError err ->
        printfn "%A" err;
        None

  go





let evalTop (env : Env) : Core -> Env option =
  function
  | TopLet(s, t1, e1) as e2 ->
      match typeOf (mkTypeEnv env) e2 with
      | Type t2 ->
          printfn "val %s : %s" s (prettyStringType t2);

          captureFreeVars env e1
          |> (fun x -> Map.add s (t2, x) env)
          |> Some

      | TypeError err ->
          printfn "%A" err;
          None

  | DefRecord (s, _) as e ->
      match typeOf (mkTypeEnv env) e with
      | Type t ->
         printfn "%s" (prettyStringType t);
         Some (Map.add s (t, Unit) env)

      | TypeError err ->
          printfn "%A" err;
          None

  | e -> failwithf "Error @ evalTop: %A" e



let evalPrgm (env1 : Env) =
  let f acc x =
    match acc with
    | None      -> None
    | Some env2 -> evalTop env2 x

  List.map exprToCore
  >> List.fold f (Some env1)



let eval (whatToPrint : ReplVerbosity) (s : string) : Env option -> Env option  =
  function
  | None     -> None
  | Some env ->
      match parse s with
      | AST (Prgm es) -> evalPrgm env es
      | AST (Expr e)  -> evalExpr whatToPrint env e
      | AST Empty     -> printfn "{}"; None
      | Error s       -> printfn "%s" s; None



let init : Env option = Some Map.empty



let wait (x: 'a) : 'a =
  printfn "waiting...";
  ignore (System.Console.ReadLine());
  x



let stop : 'a -> unit = ignore



let test1 _ =
     init
  |> eval JustResult "type Thing = (one : Bool, two : (Int, Int))"

  |> eval JustResult "rec f (g : Int -> Bool) (x : Int) : Bool = \
                        if g x \
                           then g Thing(one = True, two = (1, 0)).two.0 \
                           else g (1, 0).1"
  |> wait
  |> eval AllSteps "f (fun (x : Int) -> if x == 0 then False else True) 0" // => False
  |> wait
  |> eval AllSteps "f (fun (x : Int) -> if x == 0 then False else True) 1" // => True
  |> stop

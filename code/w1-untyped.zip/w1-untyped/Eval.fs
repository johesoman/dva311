module Eval


open Lang
open Parser
open System
open FSharpx.Text.Strings



// +++++++++
// + Error +
// +++++++++



type EvalError =
  | IfGuardNotBool     of Core * Core * Core
  | UndefinedVariable  of string
  | InvalidApplication of (Core * Core)
  | ReadInvalidFormat  of (string * string)
  | BopInvalidOperands of (Core * Op * Core)



exception EvalException of EvalError



let except (err: EvalError) =
  raise (EvalException err)



// ++++++++
// + Util +
// ++++++++



let pp x =
  printfn "pp> %A" x;
     Console.ReadLine()
  |> ignore



type ReplVerbosity =
  | AllSteps
  | JustResult



let freeVars =
  let rec go vars =
    function
    | Fix e -> go vars e

    | e when isLiteral e -> vars

    | Var s              -> Set.add s vars
    | Index(s, i, _)     -> Set.add s vars

    | Abs(Untyped s, e) ->
        Set.remove s (go vars e)

    | App(e1, e2) ->
        Set.union (go vars e1) (go vars e2)

    | Bop(e1, op, e2) ->
        Set.union (go vars e1) (go vars e2)

    | If(e1, e2, e3) ->
        Set.unionMany [ go vars e1
                      ; go vars e2
                      ; go vars e3
                      ]

    | Let(s, t, e1, e2) ->
        Set.union
          (go vars e1)
          (Set.remove s (go vars e2))

    | e -> failwithf "Error @ freeVars: %A" e

  go Set.empty >> Set.toList



let captureFreeVars env e1 =
  let f acc =
    function
    | (s2, Some(t, e2)) ->
        Let(s2, t, e2, acc)
    | (s2, None)    ->
        except (UndefinedVariable s2)

  let xs = freeVars e1

  List.map (fun x -> Map.tryFind x env) xs
  |> List.zip xs
  |> List.fold f e1



let mapExpr onIdx =
  let rec go c =
    function
    | Fix e -> Fix(go c e)

    | e when isLiteral e -> e

    | Index(s, i, n)     -> onIdx c s i n

    | Abs(p, e)          -> Abs(p, go (c + 1) e)

    | App(e1, e2)        -> App(go c e1, go c e2)

    | Bop(e1, op, e2)    -> Bop(go c e1, op, go c e2)

    | If(e1, e2, e3)     -> If(go c e1, go c e2, go c e3)

    | Let(s, t, e1, e2)  -> Let(s, t, go c e1, go (c + 1) e2)

    | e -> failwithf "Error @ mapExpr: %A" e

  go 0



let shiftExpr d =
  let onIdx c s i n =
    if c <= i
      then Index(s, i + d, n + d)
      else Index(s, i    , n + d)

  mapExpr onIdx



let substituteExpr e1 e2 =
  let onIdx c s i n =
    if c = i
      then shiftExpr (c + 1) e1
      else Index(s, i, n)

  mapExpr onIdx e2
  |> shiftExpr (-1)



// ++++++++++++++
// + Evaluation +
// ++++++++++++++



exception NoRuleApplies of Core



let rec evalBop =
  function
  | Bop(v1, op, v2) when isLiteral v2 ->
      match (v1, op, v2) with
      // Int -> Int -> Int
      | (Int x, Add, Int y) -> x +  y |> Int
      | (Int x, Sub, Int y) -> x -  y |> Int
      | (Int x, Mul, Int y) -> x *  y |> Int
      | (Int x, Div, Int y) -> x /  y |> Int

      // Int -> Int -> Bool
      | (Int x, Eq , Int y) -> x =  y |> Bool
      | (Int x, Ne , Int y) -> x <> y |> Bool
      | (Int x, Lt , Int y) -> x <  y |> Bool
      | (Int x, Le , Int y) -> x <= y |> Bool
      | (Int x, Gt , Int y) -> x >  y |> Bool
      | (Int x, Ge , Int y) -> x >= y |> Bool

      // Bool -> Bool -> Bool
      | (Bool x, Or , Bool y) -> (x || y) |> Bool
      | (Bool x, And, Bool y) -> (x && y) |> Bool
      | (Bool x, Eq , Bool y) ->  x =  y  |> Bool
      | (Bool x, Ne , Bool y) ->  x <> y  |> Bool

      // String -> String -> String
      | (String x, Add, String y) -> x + y |> Core.String

      | _ -> except (BopInvalidOperands(v1, op, v2))

  | Bop(v, op, e)   when isLiteral v  ->
      Bop(v, op, evalExpr1 e)

  | Bop(e1, op, e2) ->
      Bop(evalExpr1 e1, op, e2)

  | e -> failwithf "Error @ evalBop: %A" e



and evalExpr1 =
  function
  | Bop(_) as e -> evalBop e

  | Fix (Abs(p, e1)) as e2 ->
      substituteExpr e2 e1

  | App(Abs(_,v1), v2) when isValue v2 ->
      substituteExpr v2 v1

  | App(v, e) when isValue v ->
      App(v, evalExpr1 e)

  | App(e1, e2) ->
      App(evalExpr1 e1, e2)

  | Let(s, _, v, e) when isValue v ->
      substituteExpr v e

  | Let(s, t, e1, e2) ->
      Let(s, t, evalExpr1 e1, e2)

  | If(Bool true , e2, e3) -> e2
  | If(Bool false, e2, e3) -> e3

  | If(v, e2, e3) when isValue v ->
      except (IfGuardNotBool(v, e2, e3))

  | If(e1, e2, e3) ->
      If(evalExpr1 e1, e2, e3)

  | e -> raise (NoRuleApplies e)

  // | e -> failwithf "Error @ evalExpr1: %A" e



let printFirst =
     prettyStringCore
  >> printfn "%s"



let printNext =
      prettyStringCore
   >> toLines
   >> Seq.toArray
   >> (function
       | xs when Array.isEmpty xs -> printfn "{}"
       | xs ->
           printfn "  => %s" xs.[0];
           for x in xs.[1..] do
             printfn "     %s" x)



let evalExpr whatToPrint (env : Env) =
  let rec go isFirst e =
    let maybePrintStep _ =
      match (whatToPrint, isFirst) with
      | (AllSteps, true ) -> printFirst e
      | (AllSteps, false) -> printNext  e
      | _ -> ()

    maybePrintStep();

    try
      go false (evalExpr1 e)
    with
      | NoRuleApplies e2 ->
          match whatToPrint with
          | AllSteps   -> Some env
          | JustResult ->
              printfn "%s" (prettyStringCore e2);
              Some env
      | EvalException err ->
          printfn "%A" err
          None

  go true



let evalTop env1 =
  function
  | TopLet(s, t, e) ->
      let env2 = Map.add s (t, captureFreeVars env1 e) env1
      printfn "val %s : ?" s;
      env2

  | e -> failwithf "Error @ evalTop: %A" e



let evalPrgm env1 es =
  let f =
    function
    | None      -> fun _ -> None
    | Some env2 -> fun x ->
        try
          Some(evalTop env2 x)
        with
          | EvalException err ->
              printfn "%A" err;
              None

  List.fold f (Some env1) es



let toNameless =
  let rec go ss =
    function
    | Var s ->
        match List.tryFindIndex ((=) s) ss with
        | Some i -> Index(s, i, List.length ss)
        | None   -> except (UndefinedVariable s)

    | Fix e -> Fix(go ss e)

    | e when isLiteral e -> e

    | App(e1, e2)        -> App(go ss e1, go ss e2)

    | Bop(e1, op, e2)    -> Bop(go ss e1, op, go ss e2)

    | Abs(Untyped s, e)  -> Abs(Untyped s, go (s :: ss) e)

    | Let(s, t, e1, e2)  -> Let(s, t, go ss e1, go (s :: ss) e2)

    | If(e1, e2, e3)     -> If(go ss e1, go ss e2, go ss e3)

    | e -> failwithf "Error @ toNameless: %A" e

  go []



let eval whatToPrint s =
  function
  | None     -> None
  | Some env ->
      match parse s with
      | AST (Prgm es) ->
          evalPrgm env (List.map exprToCore es)

      | AST (Expr e) ->
             exprToCore e
          |> captureFreeVars env
          |> toNameless
          |> evalExpr whatToPrint env

      | AST Empty -> printfn "{}"; None
      | Error s   -> printfn "%s" s; None



let init = Some Map.empty



let wait x =
  printfn "waiting...";
  ignore (Console.ReadLine())
  x



let stop = ignore



let test1 _ =
     init
  |> eval JustResult "let f x y = x + y"
  |> eval JustResult "let g x y = f x y"
  |> eval JustResult "let h x y = f x x + g y y"
  |> eval JustResult "let k = 0 - 2"
  |> eval JustResult "let abs x = if x < 0 then let y = 0 - x in y else x"
  |> eval JustResult "let rec add x y = if y = 0 then x else add (x + 1) (y - 1)"
  |> wait
  |> eval AllSteps   "f 1 2"   // => 3
  |> wait
  |> eval AllSteps   "g 1 2"    // => 3
  |> wait
  |> eval AllSteps   "h 1 2"    // => 6
  |> wait
  |> eval AllSteps   "abs k"    // => 2
  |> wait
  |> eval JustResult "add 10 5" // => 15
  |> stop

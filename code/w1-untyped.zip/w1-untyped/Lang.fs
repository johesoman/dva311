module Lang



#nowarn "40" // I don't understand why I need this but I do.



open PPrint



let parensIf =
  function
  | false -> id
  | true  -> parens



type Param =
  | Untyped of string
  | Typed   of (string * string)



let prettyParam =
  function
  | Untyped s     -> txt s
  | Typed(s1, s2) -> txt s1 <+> chr ':' <+> txt s2 |> parens



let prettyParamList (ps : Param list) =
  match ps with
  | [] -> empty
  | _  -> Seq.map prettyParam ps |> vsep |> align



type Op =
  | Add
  | Sub
  | Mul
  | Div
  | Eq
  | Ne
  | Lt
  | Gt
  | Le
  | Ge
  | Or
  | And



let prettyOp =
  function
  | Add -> chr '+'
  | Sub -> chr '-'
  | Mul -> chr '*'
  | Div -> chr '/'
  | Eq  -> chr '='
  | Ne  -> txt "<>"
  | Lt  -> chr '<'
  | Gt  -> chr '>'
  | Le  -> txt "<="
  | Ge  -> txt ">="
  | Or  -> txt "||"
  | And -> txt "&&"



type Core =
  | Unit
  | TypeDef
  | Int       of int
  | Bool      of bool
  | Fix       of Core
  | Var       of string
  | String    of string
  | App       of (Core * Core)
  | Abs       of (Param * Core)
  | Bop       of (Core * Op * Core)
  | Index     of (string * int * int)
  | If        of (Core * Core * Core)
  | TopLet    of (string * string option * Core)
  | Let       of (string * string option * Core * Core)



type Type = string option



type Env = Map<string, (Type * Core)>



let isLiteral =
  function
  | Unit      -> true
  | Int(_)    -> true
  | Bool(_)   -> true
  | String(_) -> true
  | e         -> false



let isValue =
  function
  | e when isLiteral e -> true
  | Abs(_)             -> true
  | _                  -> false



let isPrim =
  function
  | Unit      -> true
  | Int(_)    -> true
  | Bool(_)   -> true
  | Var(_)    -> true
  | Index(_)  -> true
  | String(_) -> true
  | e         -> false



type Expr =
  | EUnit
  | ETypeDef
  | EFix       of Expr
  | EInt       of int
  | EBool      of bool
  | EVar       of string
  | EString    of string
  | EUop       of (Op * Expr)
  | EApp       of (Expr * Expr)
  | ESeq       of (Expr * Expr)
  | EBop       of (Expr * Op * Expr)
  | ELambda    of (Param list * Expr)
  | EIf        of (Expr * Expr * Expr)
  | ETopLet    of (string * Param list * string option * Expr)
  | ETopLetRec of (string * Param list * string option * Expr)
  | ELet       of (string * Param list * string option * Expr * Expr)
  | ELetRec    of (string * Param list * string option * Expr * Expr)



let isPrimExpr =
  function
  | EUnit      -> true
  | EInt(_)    -> true
  | EBool(_)   -> true
  | EVar(_)    -> true
  | EString(_) -> true
  | e          -> false



let precedence =
  function
  | ELet(_)         -> 1
  | ELetRec(_)      -> 1
  | ETopLet(_)      -> 1
  | ETopLetRec(_)   -> 1
  | ELambda(_)      -> 1
  | EIf(_)          -> 1
  | ESeq(_)         -> 1
  | EBop(_, Or , _) -> 2
  | EBop(_, And, _) -> 3
  | EBop(_, Eq , _) -> 4
  | EBop(_, Ne , _) -> 4
  | EBop(_, Lt , _) -> 4
  | EBop(_, Gt , _) -> 4
  | EBop(_, Le , _) -> 4
  | EBop(_, Ge , _) -> 4
  | EBop(_, Add, _) -> 5
  | EBop(_, Sub, _) -> 5
  | EBop(_, Mul, _) -> 6
  | EBop(_, Div, _) -> 6
  | EApp(_)         -> 7
  | EFix(_)         -> 8
  | EVar(_)         -> 8
  | EInt(_)         -> 8
  | EBool(_)        -> 8
  | EString(_)      -> 8
  | EUnit           -> 8
  | e -> failwithf "Error @ precedence: %A" e



let prettySig s ps =
  let go p =
    function
    | Some t ->
        p @ [chr ':'; txt s; chr '=']
    | None ->
        p @ [chr '=']

  let p = txt s :: List.map prettyParam ps

  go p >> hsep



let rec prettyTopLet s ps t e1 =
  let x = prettySig s ps t

  let y =
    if isPrimExpr e1
      then empty <+> prettyExpr e1
      else line  <^> prettyExpr e1 |> nest 2

  x <^> y



and prettyLet s ps t e1 e2 =
  let x = line <^> txt "in" <+> (prettyExpr e2 |> nest 3)

  prettyTopLet s ps t e1 <^> x



and prettyExpr =
  let rec go p1 e =
    let p2 = precedence e

    parensIf (p2 < p1) <|
    match e with
    | EUnit       -> txt "()"
    | EVar  x     -> txt x
    | EInt  x     -> txt (sprintf "%d" x)
    | EBool false -> txt "False"
    | EBool true  -> txt "True"

    | EFix e ->
        txt "fix" <+> go p2 e

    | EString s ->
        chr '"' <^> txt s <^> chr '"'

    | ELet(s, ps, t, e1, e2) ->
        txt "let" <+> prettyLet s ps t e1 e2

    | ELetRec(s, ps, t, e1, e2) ->
        txt "let rec" <+> prettyLet s ps t e1 e2

    | ELambda(ps, e1) ->
        let sgn =
          List.map prettyParam ps
          @  [txt "->"]
          |> vsep
          |> align
          |> group

        txt "fun" <.> sgn
                  <.> go p2 e1
        |> gnest 2


    | EApp(e1, e2) ->
           go p2 e1 <.> go p2 e2
        |> group


    | EIf(e1, e2, e3) ->
        let x = txt "if" <+> go p2 e1

        let y = line <^> txt "then" <^> (line <^> go p2 e2 |> gnest 2) |> nest 2

        let z = line <^> txt "else" <^> (line <^> go p2 e3 |> gnest 2) |> nest 2

        x <^> y <^> z

    | EBop(e1, op, e2) ->
        go p2 e1 <+> prettyOp op
                 <.> go p2 e2
        |> group

    | ESeq(e1, e2) ->
        go p2 e1 <^> chr ';'
                       </> go p2 e2

    | ETopLet(s, ps, t, e) ->
        txt "let" <+> prettySig s ps t

    | ETopLetRec(s, ps, t, e) ->
        txt "let rec" <+> prettySig s ps t

    | _ -> failwithf "Error @ pretty (Expr): %A" e

  go 0



let rec coreToExpr =
  function
  | Int x          -> EInt x
  | Var s          -> EVar s
  | Bool x         -> EBool x
  | TypeDef        -> ETypeDef
  | String s       -> EString s
  | Index(s, _, _) -> EVar s

  | Bop(e1, op, e2) ->
      EBop(coreToExpr e1, op, coreToExpr e2)

  | App(e1, e2) ->
      EApp(coreToExpr e1, coreToExpr e2)

  | Abs(p, e1) ->
      match coreToExpr e1 with
      | ELambda(ps, e2) -> ELambda(p :: ps, e2)
      | e2              -> ELambda([p]    , e2)

  | Let(s, t, e1, e2) ->
      match (coreToExpr e1, coreToExpr e2) with
      | (ELambda(ps, e3), e4) -> ELet(s, ps, t, e3, e4)
      | (e3             , e4) -> ELet(s, [], t, e3, e4)

  | TopLet(s, t, e1) ->
      match coreToExpr e1 with
      | ELambda(ps, e2) -> ETopLet(s, ps, t, e2)
      | e2              -> ETopLet(s, [], t, e2)

  | If(e1, e2, e3) ->
      EIf(coreToExpr e1, coreToExpr e2, coreToExpr e3)

  | Fix e -> EFix (coreToExpr e)

  | e -> failwithf "Error @ coreToExpr: %A" e



let rec exprToCore =
  function
  | EUnit     -> Unit
  | EInt x    -> Int x
  | EVar s    -> Var s
  | EBool x   -> Bool x
  | ETypeDef  -> TypeDef
  | EString s -> String s

  | EBop(e1, op, e2) ->
      Bop(exprToCore e1, op, exprToCore e2)

  | EApp(e1, e2)     ->
      App(exprToCore e1, exprToCore e2)

  | ELambda(ps, e)   ->
      exprToCore e
      |> List.foldBack (fun x y -> Abs(x, y)) ps


  | ELet(s, ps, t, e1, e2) ->
      Let(s, t, exprToCore (ELambda(ps, e1)), exprToCore e2)

  | ELetRec(s1, ps1, t1, e1, e2) ->
      match exprToCore (ETopLetRec(s1, ps1, t1, e1)) with
      | TopLet(s2, t2, e3) ->
          Let(s2, t2, e3, exprToCore e2)

      | e -> failwithf "Error2 @ exprToCore: %A" e

  | ETopLet(s, ps, t, e) ->
      TopLet(s, t, exprToCore (ELambda(ps, e)))

  | ETopLetRec(s1, ps, t, e1) ->
      let p =
        match t with
        | Some s2 -> Typed(s1, s2)
        | None    -> Untyped s1

      let e2 = exprToCore (ELambda(ps, e1))

      TopLet(s1, t, Fix (Abs(p, e2)))

  | EIf(e1, e2, e3) ->
      If(exprToCore e1, exprToCore e2, exprToCore e3)

  | e -> failwithf "Error1 @ exprToCore: %A" e



let mapOtherOnLast f g =
  let rec go =
    function
    | []    -> []
    | [x]   -> [g x]
    | x::xs -> f x :: go xs

  Seq.toList >> go >> Seq.ofList



type AST =
  | Prgm of Expr list
  | Expr of Expr
  | Empty



let prettyAST =
  function
  | Prgm [] -> txt "{}"
  | Prgm ts ->
      let withLine t = prettyExpr t <^> chr '\n'
      vsep (mapOtherOnLast withLine prettyExpr ts)

  | Expr e  -> prettyExpr e

  | Empty   -> txt "{}"



let prettyRender = render (Some 80)



let prettyStringAST =
     prettyAST
  >> prettyRender



let prettyStringASTWith n =
     prettyAST
  >> render (Some n)



let prettyStringExpr =
     prettyExpr
  >> prettyRender



let prettyStringCore =
     coreToExpr
  >> prettyExpr
  >> prettyRender

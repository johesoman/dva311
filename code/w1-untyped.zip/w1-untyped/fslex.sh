#!/usr/bin/env bash

mono /home/mrj/.nuget/packages/fslexyacc/7.0.6/build/fslex.exe --unicode LexerImpl.fsl
